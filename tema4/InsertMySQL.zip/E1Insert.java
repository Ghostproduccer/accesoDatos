package com.tema4;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.SQLException;
import java.sql.Statement;

public class E1Insert {
    public static void main(String[] args) {   
        Connection con=null;
        Statement sentencia;        
        String url= "jdbc:mysql://localhost/instituto";
       

        try {
            con = DriverManager.getConnection(url, "alumno", "0123456789");
            sentencia = con.createStatement();
            /* datos a insertar */
            String sNombreAlumno="Luis";
            String sFecha ="2000-03-01";
            double dMedia = 6.5;
            String sCurso = "DAM2";
            /*sentencia a insertar  **cuidado con las comillas*/
            StringBuffer sbCadena = new StringBuffer();
            sbCadena.append("insert into alumnos (nombre, fnac, media, curso) ");
            sbCadena.append(" VALUES ('"+sNombreAlumno+"', '"+sFecha+"', "+dMedia+",'"+sCurso+"')");
            System.out.println("Sentencia a ejecutar: "+sbCadena);
            /*Ejecutamos el Insert */
            sentencia.executeUpdate(sbCadena.toString());
            System.out.println("Se ha insertado el nuevo alumno en la base de datos desde sts");            
        }
        catch (SQLException  sqlex) {
            sqlex.printStackTrace();
        }
        finally {
            if (con != null)
                try {
                    con.close();
                } catch (SQLException e) {
                    // TODO Auto-generated catch block
                    e.printStackTrace();
                }
        }
    }
}
